package utils;

import entities.CarDealership;
import entities.Vehicle;
import entities.enums.CarDoorType;
import entities.enums.CarModelType;

public interface CarDealershipWorker {
	public void add(Vehicle vehicle);

	public void add(Vehicle... vehicles);

	public int getCountOfElements();

	public boolean isEmpty();

	public Vehicle[] getAll();

	public Vehicle getByIndex(int index);

	public void deleteVehicleByIndex(int index);

	public void deleteAllVehicles();

	public Vehicle[] findByCarModelType(CarModelType carModelType);

	public Vehicle[] findByCarDoorType(CarDoorType carDoorType);

	public Vehicle[] findByManufactoryYear(int manufactoryYear);

}
