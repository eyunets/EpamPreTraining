package utils.impl;

import java.util.Arrays;

import entities.CarDealership;
import entities.Vehicle;
import entities.enums.CarDoorType;
import entities.enums.CarModelType;
import utils.CarDealershipWorker;

public class CarDealershipWorkerImpl implements CarDealershipWorker {

	private CarDealership carDealership;

	public CarDealershipWorkerImpl(CarDealership carDealership) {
		this.carDealership = carDealership;
		// TODO Auto-generated constructor stub
	}

	@Override
	public void add(Vehicle vehicle) {
		if (isEmpty()) {
			Vehicle[] vehicles = new Vehicle[10];
			vehicles[0] = vehicle;
			carDealership.setVehicles(vehicles);
		} else {
			if (isFull()) {
				Vehicle[] vehicles = Arrays.copyOf(carDealership.getVehicles(),
						(int) (carDealership.getVehicles().length * 1.5));
				vehicles[carDealership.getVehicles().length] = vehicle;
				carDealership.setVehicles(vehicles);
			} else {
				for (int i = 0; i < carDealership.getVehicles().length; i++) {
					if (carDealership.getVehicles()[i] == null) {
						carDealership.getVehicles()[i] = vehicle;
						break;
					}
				}
			}
		}
		// TODO Auto-generated method stub

	}

	@Override
	public void add(Vehicle... vehicles) {
		// TODO Auto-generated method stub

	}

	@Override
	public int getCountOfElements() {
		int count = 0;
		Vehicle[] vehicles = carDealership.getVehicles();
		for (int i = 0; i < vehicles.length; i++) {
			if (vehicles[i] != null) {
				count++;
			}
		}
		// TODO Auto-generated method stub
		return count;
	}

	@Override
	public boolean isEmpty() {
		Vehicle[] vehicles = carDealership.getVehicles();
		for (int i = 0; i < vehicles.length; i++) {
			if (vehicles[i] != null) {
				return false;
			}
		}
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public Vehicle[] getAll() {
		int nullPointer = 0;
		Vehicle[] vehicles = carDealership.getVehicles();
		for (int i = 0; i < vehicles.length; i++) {
			if (vehicles[i] == null) {
				nullPointer = i;
				break;
			}
		}
		return Arrays.copyOfRange(vehicles, 0, nullPointer);
		// TODO Auto-generated method stub
	}

	@Override
	public Vehicle getByIndex(int index) {
		if (isEmpty()) {
			return null;
		} else {
			Vehicle[] vehicles = carDealership.getVehicles();
			if (vehicles.length >= index)
				return vehicles[index];
			else
				return null;
		}
		// TODO Auto-generated method stub
	}

	@Override
	public void deleteVehicleByIndex(int index) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteAllVehicles() {
		// TODO Auto-generated method stub

	}

	@Override
	public Vehicle[] findByCarModelType(CarModelType carModelType) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Vehicle[] findByCarDoorType(CarDoorType carDoorType) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Vehicle[] findByManufactoryYear(int manufactoryYear) {
		// TODO Auto-generated method stub
		return null;
	}

	private boolean isFull() {
		Vehicle[] vehicles = carDealership.getVehicles();
		for (int i = 0; i < vehicles.length; i++) {
			if (vehicles[i] == null) {
				return false;
			}
		}
		return true;
	}

}
