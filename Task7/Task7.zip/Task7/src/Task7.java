import java.util.Arrays;

import entities.Adress;
import entities.CarDealership;
import entities.Vehicle;
import entities.enums.CarDoorType;
import entities.enums.CarModelType;
import utils.CarDealershipWorker;
import utils.impl.CarDealershipWorkerImpl;

public class Task7 {
	public static void main(String[] args) {
		Adress adress = new Adress("Minsk", "Esenina", 143);
		CarDealership carDealership = new CarDealership(adress);
		Vehicle vehicle = new Vehicle(1994, "Renaught", CarModelType.SEDAN, CarDoorType.FIVE_DOOR, 10000);
		CarDealershipWorker carDealershipWorker = new CarDealershipWorkerImpl(carDealership);
		carDealershipWorker.add(vehicle);
		System.out.println(Arrays.toString(carDealership.getVehicles()));
	}
}
